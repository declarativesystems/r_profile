echo "+bad:x:666:" >> /etc/group
echo "+bad" >> /etc/gshadow
echo "+bad:x:666:666:bad user,,,:/:/sbin/nologin" >> /etc/passwd
echo "+bad" >> /etc/shadow