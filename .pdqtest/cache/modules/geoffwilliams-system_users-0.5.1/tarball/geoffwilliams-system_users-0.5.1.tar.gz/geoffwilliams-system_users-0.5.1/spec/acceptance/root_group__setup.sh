usermod -g 2 root
