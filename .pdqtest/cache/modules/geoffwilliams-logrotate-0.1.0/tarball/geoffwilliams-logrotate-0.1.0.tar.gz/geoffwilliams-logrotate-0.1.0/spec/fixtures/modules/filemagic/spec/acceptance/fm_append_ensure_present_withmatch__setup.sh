cp /testcase/spec/testdata/input.txt /tmp/fm_append.txt
cat >> /tmp/fm_append.txt <<END
aaa=xxx
end of appended data
END