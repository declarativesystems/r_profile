cat > /tmp/fm_prepend.txt <<END
First line
Second line
END

cat /testcase/spec/testdata/input.txt >> /tmp/fm_prepend.txt

