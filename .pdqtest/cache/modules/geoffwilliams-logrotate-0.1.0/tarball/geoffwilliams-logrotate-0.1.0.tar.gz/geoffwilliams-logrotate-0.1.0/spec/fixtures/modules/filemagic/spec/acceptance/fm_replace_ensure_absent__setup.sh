cat > /tmp/foo.txt << END
remove this line
no remove
remove this line
remove this line
END