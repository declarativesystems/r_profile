cat > /tmp/fm_gsub.txt <<END
all work and no play makes jack a dull boy
  All work and no play makes Jack a dull boy
all Work and no play makes jack a dull boy
all work and no play makes jack a dull boy
  All work and no play makes Jack a dull boy
all Work and no play makes jack a dull boy
all work and no play makes jack a dull boy
  All work and no play makes Jack a dull boy
all Work and no play makes jack a dull boy
all work and no play makes jack a dull boy
  All work and no play makes Jack a dull boy
all Work and no play makes jack a dull boy


END