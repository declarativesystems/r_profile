echo 'nuroot:*:0:0:An extra root account:/var/root:/usr/bin/false' >> /etc/passwd
echo 'nuroot2:*:0:0:An extra root account2:/var/root:/usr/bin/false' >> /etc/passwd
echo 'nuroot:*:16659:0:99999:7:::' >> /etc/shadow
