#!/bin/bash
/testcase/spec/acceptance/test_setup.sh