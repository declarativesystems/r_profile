/testcase/spec/acceptance/test_setup.sh
echo foo=a > /etc/sysctl.d/a.conf
echo bar=b > /etc/sysctl.d/b.conf
echo baz=c > /etc/sysctl.d/c.conf

