cat > /tmp/foo.txt << EOF
remove this line
no remove
remove this line
remove this line
EOF