require 'puppet/util/feature'

Puppet.features.add(:puppetclassify, :libs => ['puppetclassify'])
