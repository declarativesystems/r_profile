require 'puppet/face'
require 'puppet/application/face_base'

class Puppet::Application::Node_manager < Puppet::Application::FaceBase
end
